import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const root = path.dirname(fileURLToPath(import.meta.url));
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const model = process.env.OPENAI_MODEL;
app.disable("x-powered-by");
app.use(express.json({ limit: "40kb" }));
app.use(express.static(path.join(root, "public")));

app.get("/api/health", (_req, res) => res.json({ ok: true, aiConfigured: Boolean(client && model) }));

app.post("/api/chat", async (req, res) => {
  if (!client || !model) return res.status(503).json({ error: "AI is not configured. Add your API key and an available model name to the private server .env file." });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 14)
    return res.status(400).json({ error: "Send 1 to 14 recent messages." });
  const input = [];
  for (const m of messages) {
    if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string" ||
        !m.content.trim() || m.content.length > 4000)
      return res.status(400).json({ error: "Invalid or oversized message." });
    input.push({ role: m.role, content: m.content.trim() });
  }
  try {
    const result = await client.responses.create({
      model,
      instructions: "You are JARVIS, a clear, friendly, age-appropriate assistant. Explain school topics simply. Be honest about uncertainty. Never claim to control the user's phone, access private data, or perform actions outside this chat. Do not request passwords, payment details, or sensitive personal information. Keep replies concise unless asked for detail.",
      input,
      max_output_tokens: 900
    });
    res.json({ reply: result.output_text || "I could not generate a text response." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(502).json({ error: "AI request failed. Check the server logs and confirm your model is enabled for your API project." });
  }
});
const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`JARVIS v4.0 running on port ${port}; AI ${client && model ? "enabled" : "not configured"}`));
